from skidl import *
import os

# Create libraries directory if it doesn't exist
os.makedirs('libraries', exist_ok=True)

# Set up KiCad environment
lib_search_paths_kicad = lib_search_paths_skidl = [os.path.abspath('libraries')]
set_default_tool(KICAD)

# Circuit description
circuit_name = 'test_voltage_divider'
circuit_description = 'A test voltage divider circuit'
default_circuit.name = circuit_name
default_circuit.description = circuit_description

# Define nets
vcc = Net('VCC')  # Power
gnd = Net('GND')  # Ground
out = Net('OUT')  # Output

# Create components with footprints
r1 = Part("Device", "R", value="10k", footprint="Resistor_SMD:R_0805_2012Metric")
r2 = Part("Device", "R", value="4.7k", footprint="Resistor_SMD:R_0805_2012Metric")

# Make connections
vcc += r1[1]
r1[2] += out
out += r2[1]
r2[2] += gnd

# Generate netlist with circuit name
generate_netlist(file_=f'{circuit_name}.net')