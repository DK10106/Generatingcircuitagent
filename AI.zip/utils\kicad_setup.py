import os
import shutil
from datetime import datetime
import urllib.request
import sys
from generate_circuit import setup_kicad_env as _setup_kicad_env

def setup_kicad_env(verbose=True):
    """Set up minimal KiCad environment for testing"""
    def log(msg):
        if verbose:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
    
    log("Setting up minimal KiCad environment...")
    
    # Create necessary directories
    base_dir = os.path.dirname(os.path.dirname(__file__))
    libraries_dir = os.path.join(base_dir, 'libraries')
    os.makedirs(libraries_dir, exist_ok=True)
    
    # Add libraries directory to Python path
    if libraries_dir not in sys.path:
        sys.path.append(libraries_dir)
    
    # List of required KiCad symbol libraries
    required_libs = {
        'Device.kicad_sym': 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/Device.kicad_sym',
        'power.kicad_sym': 'https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/power.kicad_sym'
    }
    
    # Download required libraries
    for lib_name, lib_url in required_libs.items():
        lib_path = os.path.join(libraries_dir, lib_name)
        if not os.path.exists(lib_path):
            log(f"Downloading {lib_name}...")
            try:
                urllib.request.urlretrieve(lib_url, lib_path)
                log(f"✓ Downloaded {lib_name}")
            except Exception as e:
                log(f"✗ Error downloading {lib_name}: {str(e)}")
                return False
    
    # Set environment variables to point to our libraries directory
    abs_lib_dir = os.path.abspath(libraries_dir)
    os.environ['KICAD_SYMBOL_DIR'] = abs_lib_dir
    os.environ['KICAD6_SYMBOL_DIR'] = abs_lib_dir
    os.environ['KICAD7_SYMBOL_DIR'] = abs_lib_dir
    os.environ['KICAD8_SYMBOL_DIR'] = abs_lib_dir
    
    # Create a backup library for skidl
    backup_lib = os.path.join(libraries_dir, 'backup_lib.py')
    if not os.path.exists(backup_lib):
        log("Creating backup library...")
        with open(backup_lib, 'w') as f:
            f.write('''from skidl import Pin, Part, Alias, SchLib, SKIDL, TEMPLATE
from skidl.pin import pin_types

SKIDL_lib_version = '0.0.1'

backup_lib = SchLib(tool=SKIDL).add_parts(*[
    Part(**{
        'name':'R',
        'dest':TEMPLATE,
        'tool':SKIDL,
        'aliases':Alias({'R'}),
        'ref_prefix':'R',
        'fplist':['R_*'],
        'footprint':'Resistor_SMD:R_0805_2012Metric',
        'pins':[
            Pin(num='1',name='~',func=pin_types.PASSIVE,unit=1),
            Pin(num='2',name='~',func=pin_types.PASSIVE,unit=1)
        ]
    }),
    Part(**{
        'name':'C',
        'dest':TEMPLATE,
        'tool':SKIDL,
        'aliases':Alias({'C'}),
        'ref_prefix':'C',
        'fplist':['C_*'],
        'footprint':'Capacitor_SMD:C_0805_2012Metric',
        'pins':[
            Pin(num='1',name='~',func=pin_types.PASSIVE,unit=1),
            Pin(num='2',name='~',func=pin_types.PASSIVE,unit=1)
        ]
    })
])''')
        log("✓ Created backup library")
    
    # Create a symbolic link to Device.kicad_sym as Device.lib for backward compatibility
    device_lib = os.path.join(libraries_dir, 'Device.lib')
    device_sym = os.path.join(libraries_dir, 'Device.kicad_sym')
    if os.path.exists(device_sym) and not os.path.exists(device_lib):
        try:
            if os.name == 'nt':  # Windows
                import subprocess
                subprocess.run(['mklink', device_lib, device_sym], shell=True)
            else:  # Unix-like
                os.symlink(device_sym, device_lib)
            log("✓ Created symbolic link for Device library")
        except Exception as e:
            log(f"✗ Warning: Could not create symbolic link: {str(e)}")
            # If symbolic link fails, copy the file instead
            try:
                shutil.copy2(device_sym, device_lib)
                log("✓ Copied Device library instead")
            except Exception as e:
                log(f"✗ Warning: Could not copy Device library: {str(e)}")
    
    log("✓ Environment setup complete")
    return True

def setup_kicad_env():
    """Setup KiCad environment by calling the main setup function"""
    _setup_kicad_env()

if __name__ == "__main__":
    setup_kicad_env() 