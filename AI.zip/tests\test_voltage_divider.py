import os
import sys

# Add the parent directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from utils.code_manager import CodeManager
from utils.kicad_setup import setup_kicad_env

def test_code_generation():
    # Set up minimal KiCad environment
    setup_kicad_env()
    
    # Sample LLM response with a voltage divider circuit
    test_response = r"""[EXPLANATION]
This is a simple voltage divider circuit that takes a 5V input and produces a 3.3V output.

[CODE]
from skidl import *
import os

# Create necessary directories
os.makedirs('libraries', exist_ok=True)

# Set up KiCad environment
lib_search_paths_kicad = lib_search_paths_skidl = [os.path.abspath('libraries')]
set_default_tool(KICAD)

# Circuit description
circuit_name = 'test_voltage_divider'
circuit_description = 'A test voltage divider circuit'
default_circuit.name = circuit_name
default_circuit.description = circuit_description

# Define nets
vcc = Net('VCC')  # Power
gnd = Net('GND')  # Ground
out = Net('OUT')  # Output

# Create components with footprints
r1 = Part("Device", "R", value="10k", footprint="Resistor_SMD:R_0805_2012Metric")
r2 = Part("Device", "R", value="4.7k", footprint="Resistor_SMD:R_0805_2012Metric")

# Make connections
vcc += r1[1]
r1[2] += out
out += r2[1]
r2[2] += gnd

# Generate netlist with circuit name
generate_netlist(file_=f'{circuit_name}.net')
[/CODE]

[INSTRUCTIONS]
The code will create a voltage divider circuit and generate a netlist file."""
    
    # Initialize CodeManager
    code_manager = CodeManager()
    
    # Process the test response
    py_file, net_file, stdout, stderr = code_manager.process_code_generation(test_response)
    
    # Print results
    print("\nTest Results:")
    print(f"Python file: {py_file}")
    print(f"Netlist file: {net_file}")
    print(f"Output: {stdout}")
    print(f"Errors: {stderr}")

if __name__ == "__main__":
    test_code_generation() 