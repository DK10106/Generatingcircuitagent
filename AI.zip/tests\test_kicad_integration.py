import os
import sys
import shutil
from datetime import datetime

# Add the parent directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.kicad_wrapper import KiCadWrapper

def test_kicad_integration():
    """Test the KiCad integration by creating example circuits"""
    
    def log(msg):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {msg}")
    
    # Initialize KiCad wrapper
    log("Initializing KiCad wrapper...")
    kicad = KiCadWrapper()
    
    # Test voltage divider circuit
    log("\nTesting voltage divider circuit generation...")
    netlist_file, project_file = kicad.create_voltage_divider(
        name="voltage_divider_5v_3v3",
        vin=5.0,
        vout=3.3
    )
    
    # Verify files were created
    log("\nVerifying generated files...")
    assert os.path.exists(netlist_file), f"Netlist file not found: {netlist_file}"
    assert os.path.exists(project_file), f"Project file not found: {project_file}"
    
    # Test RC filter circuit
    log("\nTesting RC filter circuit generation...")
    netlist_file, project_file = kicad.create_rc_filter(
        name="rc_filter_1khz",
        cutoff_freq=1000  # 1kHz cutoff
    )
    
    # Verify files were created
    assert os.path.exists(netlist_file), f"Netlist file not found: {netlist_file}"
    assert os.path.exists(project_file), f"Project file not found: {project_file}"
    
    # Print success message with file locations
    log("\n✓ Test completed successfully!")
    log("Generated files can be found in:")
    log(f"- Voltage divider: {os.path.dirname(netlist_file)}")
    log(f"- RC filter: {os.path.dirname(project_file)}")

if __name__ == "__main__":
    test_kicad_integration() 