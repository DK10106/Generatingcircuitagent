from skidl import *
import os
import urllib.request

# Create libraries directory if it doesn't exist
os.makedirs('libraries', exist_ok=True)

# Download the Device.kicad_sym file if it doesn't exist
device_lib_path = os.path.join('libraries', 'Device.kicad_sym')
if not os.path.exists(device_lib_path):
    url = "https://gitlab.com/kicad/libraries/kicad-symbols/-/raw/master/Device.kicad_sym"
    urllib.request.urlretrieve(url, device_lib_path)

# Set the library search path to our local libraries directory
lib_search_paths_kicad = lib_search_paths_skidl = [os.path.abspath('libraries')]

# Set default tool to KiCad
set_default_tool(KICAD)

# Circuit description
circuit_name = 'low_pass_filter'  # Replace with appropriate name
circuit_description = 'A low-pass RC filter circuit'  # Replace with appropriate description
default_circuit.name = circuit_name
default_circuit.description = circuit_description

# Define nets
vcc = Net('VCC')  # Power
gnd = Net('GND')  # Ground
out = Net('OUT')  # Output

# Create components with footprints
r1 = Part("Device", "R", value="3k", footprint="Resistor_SMD:R_0805_2012Metric")
c1 = Part("Component", "C", value="47uF", footprint="Capacitor_SMD:C_0603_2012Metric")
l1 = Part("Component", "L", value="1k", footprint="Inductor_SMD:L_0805_2012Metric")

# Make connections
vcc += r1[1]
r1[2] += out
out += c1[1]
c1[2] += l1[1]
l1[2] += gnd

# Generate netlist with circuit name
generate_netlist(file_=f'{circuit_name}.net')

        Format your response EXACTLY like this, with NO VARIATIONS:

        [EXPLANATION] Brief explanation of what the code will do
        [/EXPLANATION]

        [CODE] Your complete code here, following the structure above but with appropriate values