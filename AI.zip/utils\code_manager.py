import os
import re
import subprocess
import sys
from datetime import datetime
from typing import Tuple, Optional

class CodeManager:
    """Manages code generation, saving, and execution for KiCad circuits"""
    
    def __init__(self):
        """Initialize the code manager"""
        # Create generated_code directory if it doesn't exist
        self.code_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "generated_code")
        os.makedirs(self.code_dir, exist_ok=True)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] CodeManager initialized at {self.code_dir}")
    
    def extract_code_from_response(self, response: str) -> Optional[str]:
        """Extract code from LLM response"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Extracting code from response...")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Raw response:\n{response}")
        
        # Try to extract code between [CODE] tags
        code_match = re.search(r'\[CODE\](.*?)\[/CODE\]', response, re.DOTALL)
        if code_match:
            code = code_match.group(1).strip()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found code between [CODE] tags")
            return code
            
        # Try to extract code between python markers
        code_parts = response.split('```python')
        if len(code_parts) > 1:
            code = code_parts[1].split('```')[0].strip()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found code between python markers")
            return code
            
        # Try to extract code between triple backticks without python
        code_parts = response.split('```')
        if len(code_parts) > 1:
            # Get the first code block
            code = code_parts[1].strip()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found code between triple backticks")
            return code
            
        # Try to extract any Python-like code block
        if 'from skidl import' in response:
            # Find the start of the code block
            start_idx = response.find('from skidl import')
            # Find the end by looking for common terminators
            end_markers = ['\n\n[', '\n\nBrief instructions', '\n\nNext steps']
            end_indices = [response[start_idx:].find(marker) for marker in end_markers]
            end_indices = [i for i in end_indices if i != -1]
            if end_indices:
                end_idx = min(end_indices)
                code = response[start_idx:start_idx + end_idx].strip()
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found code by content analysis")
                return code
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No code found in response")
        return None
    
    def validate_code(self, code: str) -> Tuple[bool, str]:
        """Validate the code for required elements"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Validating code...")
        
        # Check for circuit name definition
        if "circuit_name = '" not in code and 'circuit_name = "' not in code:
            return False, "Code must define circuit_name variable with a string value"
        
        # Check for netlist generation
        if "generate_netlist(file_=f'{circuit_name}.net')" not in code:
            return False, "Code must include proper netlist generation with circuit_name"
        
        # Check for required imports and setup
        required_elements = [
            'from skidl import *',
            'import os',
            'lib_search_paths_kicad',
            'set_default_tool(KICAD)',
            'default_circuit.name = circuit_name'
        ]
        
        missing_elements = [elem for elem in required_elements if elem not in code]
        if missing_elements:
            return False, f"Code is missing required elements: {', '.join(missing_elements)}"
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Code validation successful")
        return True, "Code validation successful"
    
    def save_code(self, code: str) -> Optional[str]:
        """Save code to a Python file"""
        try:
            # Generate unique filename
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            py_file = os.path.join(self.code_dir, f'circuit_{timestamp}.py')
            
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Saving code to {py_file}")
            with open(py_file, 'w') as f:
                f.write(code)
                
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Code saved successfully")
            return py_file
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ Error saving code: {str(e)}")
            return None
    
    def run_code(self, py_file: str) -> Tuple[Optional[str], str, str]:
        """Run the Python code and return the netlist file path and any output"""
        try:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Executing code...")
            result = subprocess.run(
                [sys.executable, py_file],
                capture_output=True,
                text=True,
                cwd=self.code_dir
            )
            
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Code execution completed")
            print(f"[{datetime.now().strftime('%H:%M:%S')}] stdout: {result.stdout}")
            print(f"[{datetime.now().strftime('%H:%M:%S')}] stderr: {result.stderr}")
            
            # Find generated .net file
            net_files = [f for f in os.listdir(self.code_dir) if f.endswith('.net')]
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Found .net files: {net_files}")
            
            latest_net = max([os.path.join(self.code_dir, f) for f in net_files], key=os.path.getctime) if net_files else None
            if latest_net:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found latest .net file: {latest_net}")
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No .net files found")
            
            return latest_net, result.stdout, result.stderr
            
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ Error running code: {str(e)}")
            return None, "", str(e)
    
    def process_code_generation(self, llm_response: str) -> Tuple[Optional[str], Optional[str], str, str]:
        """Process the complete code generation workflow"""
        # Extract code
        code = self.extract_code_from_response(llm_response)
        if not code:
            return None, None, "", "No code found in response"
        
        # Validate code
        is_valid, validation_msg = self.validate_code(code)
        if not is_valid:
            return None, None, "", validation_msg
        
        # Save code
        py_file = self.save_code(code)
        if not py_file:
            return None, None, "", "Failed to save code"
        
        # Run code
        net_file, stdout, stderr = self.run_code(py_file)
        
        return py_file, net_file, stdout, stderr 