from skidl import Pin, Part, Alias, SchLib, SKIDL, TEMPLATE
from skidl.pin import pin_types

SKIDL_lib_version = '0.0.1'

backup_lib = SchLib(tool=SKIDL).add_parts(*[
    Part(**{
        'name':'R',
        'dest':TEMPLATE,
        'tool':SKIDL,
        'aliases':Alias({'R'}),
        'ref_prefix':'R',
        'fplist':['R_*'],
        'footprint':'Resistor_SMD:R_0805_2012Metric',
        'pins':[
            Pin(num='1',name='~',func=pin_types.PASSIVE,unit=1),
            Pin(num='2',name='~',func=pin_types.PASSIVE,unit=1)
        ]
    }),
    Part(**{
        'name':'C',
        'dest':TEMPLATE,
        'tool':SKIDL,
        'aliases':Alias({'C'}),
        'ref_prefix':'C',
        'fplist':['C_*'],
        'footprint':'Capacitor_SMD:C_0805_2012Metric',
        'pins':[
            Pin(num='1',name='~',func=pin_types.PASSIVE,unit=1),
            Pin(num='2',name='~',func=pin_types.PASSIVE,unit=1)
        ]
    })
])