import os
import subprocess
import sys
from pathlib import Path

def find_kicad_exe():
    """Find KiCad executable in standard installation locations"""
    possible_paths = [
        # Windows paths
        r"C:\Program Files\KiCad\7.0\bin\kicad.exe",
        r"C:\Program Files\KiCad\6.0\bin\kicad.exe",
        # Add more paths as needed
    ]
    
    for path in possible_paths:
        if os.path.exists(path):
            return path
    
    return None

def open_kicad_project(project_file):
    """Open a KiCad project file directly in KiCad
    
    Args:
        project_file (str): Path to the .kicad_pro file
    """
    # Convert to absolute path
    project_path = os.path.abspath(project_file)
    
    if not os.path.exists(project_path):
        print(f"Error: Project file not found: {project_path}")
        return False
    
    # Find KiCad executable
    kicad_exe = find_kicad_exe()
    if not kicad_exe:
        print("Error: KiCad executable not found. Please make sure KiCad is installed.")
        return False
    
    try:
        # Open KiCad with the project file
        subprocess.Popen([kicad_exe, project_path])
        print(f"Opening KiCad project: {project_path}")
        return True
    except Exception as e:
        print(f"Error opening KiCad: {str(e)}")
        return False

if __name__ == "__main__":
    # If script is run directly, use the first argument as the project file
    if len(sys.argv) < 2:
        print("Usage: python open_kicad.py <path_to_kicad_project.kicad_pro>")
        sys.exit(1)
    
    project_file = sys.argv[1]
    open_kicad_project(project_file) 