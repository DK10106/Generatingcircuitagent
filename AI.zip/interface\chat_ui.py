from datetime import datetime
import streamlit as st
import sys
import os
import time
import re
import subprocess

# Add the parent directory to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.llm_engine import LLMEngine
from core.kicad_wrapper import KiCadWrapper
from utils.code_manager import CodeManager
from utils.kicad_setup import setup_kicad_env
from core.circuit_generator import CircuitGenerator
from utils.open_kicad import open_kicad_project

class KiCadAssistantUI:
    def __init__(self):
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Starting KiCad AI Assistant UI...")
        
        # Set up KiCad environment first
        setup_kicad_env()
        
        # Initialize other components
        self.llm = LLMEngine()
        self.kicad = KiCadWrapper()
        self.code_manager = CodeManager()
        
        # Create generated_code directory if it doesn't exist
        self.code_dir = os.path.join(os.path.dirname(os.path.dirname(__file__)), "generated_code")
        os.makedirs(self.code_dir, exist_ok=True)
        
        # Initialize session state for chat history
        if 'messages' not in st.session_state:
            st.session_state.messages = []
        if 'circuit_generator' not in st.session_state:
            st.session_state.circuit_generator = CircuitGenerator()
        if 'llm_engine' not in st.session_state:
            st.session_state.llm_engine = LLMEngine()
        if 'output_dir' not in st.session_state:
            st.session_state.output_dir = os.path.join(os.getcwd(), 'kicad_output')
            os.makedirs(st.session_state.output_dir, exist_ok=True)
        print(f"[{datetime.now().strftime('%H:%M:%S')}] UI initialization complete!")
    
    def extract_sections(self, response: str) -> dict:
        """Extract sections from the structured response"""
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Extracting sections from response...")
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Raw response:\n{response}")
        
        sections = {}
        
        # Extract explanation
        explanation_match = re.search(r'\[EXPLANATION\](.*?)\[/EXPLANATION\]', response, re.DOTALL)
        if explanation_match:
            sections['explanation'] = explanation_match.group(1).strip()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found explanation section")
        else:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No explanation section found")
            # Fallback: Try to extract explanation from unstructured text
            sections['explanation'] = response.split('Python code implementation:')[0].strip()
        
        # Extract code
        code_match = re.search(r'\[CODE\](.*?)\[/CODE\]', response, re.DOTALL)
        if code_match:
            sections['code'] = code_match.group(1).strip()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found code section")
        else:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No code section found")
            # Fallback: Try to extract code between python markers
            code_parts = response.split('```python')
            if len(code_parts) > 1:
                code = code_parts[1].split('```')[0].strip()
                sections['code'] = code
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found code using fallback method")
        
        # Extract instructions
        instructions_match = re.search(r'\[INSTRUCTIONS\](.*?)\[/INSTRUCTIONS\]', response, re.DOTALL)
        if instructions_match:
            sections['instructions'] = instructions_match.group(1).strip()
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found instructions section")
        else:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No instructions section found")
            # Fallback: Try to extract instructions from unstructured text
            if 'Brief instructions' in response:
                sections['instructions'] = response.split('Brief instructions')[1].split('Next steps')[0].strip()
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found instructions using fallback method")
        
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Extracted sections: {list(sections.keys())}")
        return sections
    
    def save_and_run_code(self, code: str) -> tuple:
        """Save code to a file and run it"""
        try:
            # Validate code
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Validating code...")
            
            # Check for circuit name definition
            if "circuit_name = '" not in code and 'circuit_name = "' not in code:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No circuit name definition found")
                return None, None, "", "Error: Code must define circuit_name variable with a string value"
            
            # Check for netlist generation
            if "generate_netlist(file_=f'{circuit_name}.net')" not in code:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No proper netlist generation found")
                return None, None, "", "Error: Code must include proper netlist generation with circuit_name"
            
            # Check for required imports and setup
            required_elements = [
                'from skidl import *',
                'import os',
                'lib_search_paths_kicad',
                'set_default_tool(KICAD)',
                'default_circuit.name = circuit_name'
            ]
            
            missing_elements = [elem for elem in required_elements if elem not in code]
            if missing_elements:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ Missing required elements: {missing_elements}")
                return None, None, "", f"Error: Code is missing required elements: {', '.join(missing_elements)}"
            
            # Generate unique filename
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            py_file = os.path.join(self.code_dir, f'circuit_{timestamp}.py')
            
            # Save code to file
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Saving code to {py_file}")
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Code to save:\n{code}")
            
            with open(py_file, 'w') as f:
                f.write(code)
            
            # Run the code
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Executing code...")
            result = subprocess.run(
                [sys.executable, py_file],
                capture_output=True,
                text=True,
                cwd=self.code_dir
            )
            
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Code execution completed")
            print(f"[{datetime.now().strftime('%H:%M:%S')}] stdout: {result.stdout}")
            print(f"[{datetime.now().strftime('%H:%M:%S')}] stderr: {result.stderr}")
            
            # Find generated .net file
            net_files = [f for f in os.listdir(self.code_dir) if f.endswith('.net')]
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Found .net files: {net_files}")
            
            latest_net = max([os.path.join(self.code_dir, f) for f in net_files], key=os.path.getctime) if net_files else None
            if latest_net:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✓ Found latest .net file: {latest_net}")
            else:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ No .net files found")
            
            return py_file, latest_net, result.stdout, result.stderr
            
        except Exception as e:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] ✗ Error running code: {str(e)}")
            return None, None, "", str(e)
    
    def process_message(self, message: str) -> str:
        """
        Process a message from the user
        Args:
            message: User's message
        Returns:
            Assistant's response
        """
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Processing user message: {message[:50]}...")
        start_time = time.time()
        
        # Add circuit context if available
        context = self.kicad.get_circuit_info()
        
        # Process the query
        with st.spinner('Generating response...'):
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Requesting response from LLM...")
            response = self.llm.process_user_query(message, context)
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Got response from LLM")
            
            # Process code generation if present
            py_file, net_file, stdout, stderr = self.code_manager.process_code_generation(response)
            
            # Format the complete response
            if py_file:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Code file created successfully")
                response += f"\n\nCode has been saved to: {os.path.basename(py_file)}\n"
                if net_file:
                    response += f"Generated netlist: {os.path.basename(net_file)}\n"
                if stdout:
                    response += f"\nOutput:\n{stdout}"
                if stderr:
                    response += f"\nErrors:\n{stderr}"
            
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Final response prepared")
        
        elapsed_time = time.time() - start_time
        print(f"[{datetime.now().strftime('%H:%M:%S')}] Response generated in {elapsed_time:.1f}s")
        return response
    
    def display_chat_message(self, message: str, is_user: bool = True):
        """Display a chat message"""
        if is_user:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Displaying user message")
            st.chat_message("user").write(message)
        else:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Displaying assistant response")
            st.chat_message("assistant").write(message)
    
    def run(self):
        """Run the Streamlit interface"""
        st.title("KiCad AI Circuit Generator")
        st.write("""
        This AI assistant helps you create KiCad circuits through natural language.
        It generates actual KiCad files (.net, .kicad_pro, .kicad_sch) that you can open in KiCad.
        
        Example commands:
        - Create a voltage divider that converts 5V to 3.3V
        - Generate an RC low-pass filter with 1kHz cutoff frequency
        - Design a custom circuit with [describe your requirements]
        """)
        
        # Display chat history
        if st.session_state.messages:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Loading chat history...")
        for message in st.session_state.messages:
            self.display_chat_message(message["content"], message["is_user"])
        
        # Chat input
        if prompt := st.chat_input("Describe the circuit you want to create..."):
            print(f"\n[{datetime.now().strftime('%H:%M:%S')}] New user message received")
            # Add user message to chat
            st.session_state.messages.append({"content": prompt, "is_user": True})
            self.display_chat_message(prompt)
            
            # Get and display assistant response
            response = self.process_message(prompt)
            st.session_state.messages.append({"content": response, "is_user": False})
            self.display_chat_message(response, False)
        
        # Example queries in the sidebar
        with st.sidebar:
            st.header("Example Queries")
            st.write("Click any example to see a code implementation:")
            example_queries = [
                "Create a 1kHz low-pass RC filter circuit using skidl",
                "Design a voltage divider with 5V input and 3.3V output",
                "Implement a basic LED circuit with current limiting resistor",
                "Create a full-wave bridge rectifier circuit"
            ]
            for query in example_queries:
                if st.button(query):
                    print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Example query selected: {query}")
                    # Add example query to chat
                    st.session_state.messages.append({"content": query, "is_user": True})
                    self.display_chat_message(query)
                    
                    # Get and display assistant response
                    response = self.process_message(query)
                    st.session_state.messages.append({"content": response, "is_user": False})
                    self.display_chat_message(response, False)

def display_circuit_files(circuit_dir: str, files: list):
    """Display generated circuit files and instructions with download buttons."""
    if not files:
        st.error("No files were generated. Please check the logs.")
        return

    st.success("✓ Circuit files generated successfully!")
    st.write("### Download Your KiCad Files")

    # Display a download button for each generated file
    for file_path in files:
        file_name = os.path.basename(file_path)
        try:
            with open(file_path, "rb") as fp:
                st.download_button(
                    label=f"Download {file_name}",
                    data=fp,
                    file_name=file_name,
                    mime="application/octet-stream"
                )
        except FileNotFoundError:
            st.error(f"Could not find file: {file_name}")

    # Display the netlist content for review
    netlist_file = next((f for f in files if f.endswith('.net')), None)
    if netlist_file:
        st.write("### Generated Netlist")
        with open(netlist_file, 'r') as f:
            st.code(f.read(), language='scheme')

    # Keep the "Open in KiCad" button for local development
    project_file = next((f for f in files if f.endswith('.kicad_pro')), None)
    if project_file:
        st.write("---")
        if st.button("Open Project in KiCad (Local Only)"):
            if open_kicad_project(project_file):
                st.info("Attempting to open project in KiCad...")
            else:
                st.error("Failed to open KiCad. Please ensure it is installed and accessible.")

def main():
    print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Starting KiCad AI Assistant application...")
    assistant = KiCadAssistantUI()
    assistant.run()

if __name__ == "__main__":
    main() 